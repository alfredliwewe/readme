<?php
require 'config.php';
require 'functions.php';

$db = new sqlite3("data.db3");
?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?=$config['name'];?></title>
	<?php
	require '../head/links.php';
	?>

	<link rel='stylesheet' href='src/codemirror.css'>
	<!--<script src='src/codemirror.js'></script>
	<script src='src/codemirror_jsx.js'></script>-->
	<!-- CodeMirror JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/codemirror.min.js"></script>
  
  <!-- Language Mode for HTML -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/mode/htmlmixed/htmlmixed.min.js"></script>
  
  <!-- Additional Modes for Embedded CSS and JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/mode/xml/xml.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/mode/javascript/javascript.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/mode/css/css.min.js"></script>
  
  <!-- Optional: Addons for Enhanced Functionality -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/addon/edit/closetag.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.13/addon/edit/closebrackets.min.js"></script>
</head>
<body>
	<div class="p-2 bg-blue-700 text-white" id="top" style="background-color:#001d3d">
		<?=$config['name'];?>
	</div>
	<div class="w3-row" id="major">
		<div class="w3-col m2 w3-border-right">
			<div class="p-2">
				<h5>Menu</h5>
				<?php
				$read = $db->query("SELECT * FROM menus WHERE parent = '0' ");
				while ($row = $read->fetchArray()) {
					?>
					<div>
						<i class="fa fa-angle-right"></i> <a href="./?read=<?=$row['id'];?>"><?=$row['name'];?></a>
					</div>
					<?php
				}
				?>
			</div>
		</div>
		<div class="w3-col m8">
			<div class="p-3 text-lg">
				<?php
				if (isset($_GET['read'])) {
					$data = getData("menus", ['id' => (int)$_GET['read']]);

					require 'includes/ParseDown.php';
					$Parsedown = new Parsedown();

					// Convert Markdown to HTML
					$html = $Parsedown->text(file_get_contents("./uploads/".$data['md_file']));
					echo $html;
				}
				?>
			</div>
			<div class="p-3 bg-blue-100">
				<div class="w3-center py-3">From <a href="#">malawi-schools.com</a></div>
			</div>
		</div>
		<div class="w3-col m2 w3-border-left">
			<div class="p-3">
				<?php
				if (isset($Parsedown)) {
					foreach ($Parsedown->headings as $row) {
						?>
						<div class="block">
							<a href="#<?=$row['id'];?>"><?=$row['text'];?></a>
						<?php
					}
				}
				?>
			</div>
		</div>
	</div>
</body>
<script type="text/javascript">
	window.onload = function() {
		let div = document.getElementById("major");
		for (let i = 0; i < div.childNodes.length; i++) {
			const childNode = div.childNodes[i];
			$(childNode).height(innerHeight - _('top').clientHeight).css('overflow-y','auto');
		}


		// Select all textareas with the class 'code-editor'
		var textareas = document.querySelectorAll('.htmlHigh');

		textareas.forEach(function(textarea) {
			CodeMirror.fromTextArea(textarea, {
				mode: "htmlmixed",
				lineWrapping: true,
				smartIndent: false,
				htmlMode: true,
				autocorrect: false,      
				addModeClass: true,


				//mode: "text/html",
				//htmlMode: true,
				//lineWrapping: true,
				//smartIndent: false,
				//addModeClass: true

			});
		});
	}
</script>
</html>